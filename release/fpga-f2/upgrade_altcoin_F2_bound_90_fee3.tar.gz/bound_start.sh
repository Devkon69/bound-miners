#!/bin/sh
# bound_start.sh - run BOUND (BoundHash) on the BlackMiner control board.
# Same procedure as noid_start.sh; it only uses different file names, so the
# NOID files and the vendor firmware stay untouched.
#
# Files (put them in /config/bound/, which survives reboots):
#   /config/bound/bound-miner          the program (bound-miner-armv7)
#   /config/bound/bound.conf           options for bound-miner, one line (see below)
#   /config/bound/fan.conf          optional: PWM settings for 4-wire fans (see below)
#   /fpgabit/fpgaminer_top_bound.bit   the BOUND bitstream (bound_f2.bit)
#
#   sh /config/bound/bound_start.sh bench     load the bitstream and run a 60 s self test
#   sh /config/bound/bound_start.sh start     load the bitstream and mine in background (screen "bound")
#   sh /config/bound/bound_start.sh stop      stop mining (vendor monitor stays paused)
#   sh /config/bound/bound_start.sh restore   stop mining and give the machine back to cgminer
#   sh /config/bound/bound_start.sh log       show the miner screen (Ctrl-A D to leave)
#   sh /config/bound/bound_start.sh fan-info  show the PWM and tachometer state
#   sh /config/bound/bound_start.sh fan PCT   set the fan to PCT % and measure rpm (miner stopped)
#
# The vendor firmware is not modified: a reboot brings back the original cgminer setup.
#
# Normally BOUND runs from the web interface (coin "bound" on the Pool/Miner page, installed with
# the web upgrade package): this script is only for tests over ssh. "bench" and "stop" stop the
# web miner; "restore" gives the machine back to the web interface (it restarts the chosen coin).
#
# bound.conf example:
#   --pool stratum+tcp://bound.ariabrain.com:3373 --user YOUR_BOUND_ADDRESS.f2

# Fans (4-wire PWM fan such as the Noctua NF-F12/NF-A12 industrialPPC-3000 PWM), both fans
# share one PWM output; the two tachometers are read separately.
#   /config/bound/fan.conf:  PWM_PERIOD_NS=40000      25 kHz, the Intel/Noctua PWM frequency (vendor: 100000)
#   bound.conf:       --pwm-period 40000 --fan-min 20 --fan-max 100     (no --no-fan)

DIR=/config/bound
BIT=fpgaminer_top_bound.bit
PWM_DIR=/sys/class/pwm/pwm1
TACH_IRQS="148 164"
PWM_PERIOD_NS=
[ -f $DIR/fan.conf ] && . $DIR/fan.conf

# /sbin/monitorcg (respawned by /etc/inittab) restarts cgminer, which reloads the
# 0xBTC bitstream and grabs the serial ports. It is frozen with SIGSTOP while BOUND
# runs (init only respawns it when it exits) and resumed with SIGCONT on stop.
monitor_pids() {
    ps w | grep -E '/sbin/monitor(cg|sd)' | grep -v grep | awk '{print $1}'
}

pause_monitor() {
    for p in `monitor_pids`; do kill -STOP $p && echo "paused monitor $p"; done
}

resume_monitor() {
    for p in `monitor_pids`; do kill -CONT $p && echo "resumed monitor $p"; done
}

# set the PWM frequency from fan.conf (duty is set to 100 % of the new period)
setup_pwm() {
    [ -n "$PWM_PERIOD_NS" ] || return 0
    if [ ! -f $PWM_DIR/period_ns ]; then echo "fan: $PWM_DIR/period_ns not found"; return 0; fi
    old=`cat $PWM_DIR/period_ns`
    if [ "$old" != "$PWM_PERIOD_NS" ]; then
        [ -f $PWM_DIR/run ] && echo 0 > $PWM_DIR/run
        echo 0 > $PWM_DIR/duty_ns
        echo $PWM_PERIOD_NS > $PWM_DIR/period_ns || echo "fan: cannot set period_ns"
    fi
    echo $PWM_PERIOD_NS > $PWM_DIR/duty_ns
    [ -f $PWM_DIR/run ] && echo 1 > $PWM_DIR/run
    echo "fan: PWM period `cat $PWM_DIR/period_ns` ns (was $old), duty `cat $PWM_DIR/duty_ns` ns"
}

# tachometer counters from /proc/interrupts, one per line
tach_counts() {
    for i in $TACH_IRQS; do
        awk -v irq="$i:" '$1 == irq { print $2; f = 1 } END { if (!f) print -1 }' /proc/interrupts
    done
}

# --fan... and --freq options of the .conf, so the bench runs like mining
fan_opts() {
    [ -f $DIR/bound.conf ] || return 0
    awk '{ for (i = 1; i <= NF; i++) {
             if ($i == "--no-fan" || $i == "--overclock") printf "%s ", $i
             else if ($i ~ /^--(fan|fan-min|fan-max|fan-irq|pwm-path|pwm-period|freq|freq-fpga|vco-max)$/) { printf "%s %s ", $i, $(i+1); i++ }
         } }' $DIR/bound.conf
}

load_bitstream() {
    pause_monitor
    echo "stopping cgminer ..."
    /etc/init.d/cgminer.sh stop >/dev/null 2>&1
    killall -9 noid-miner bound-miner 2>/dev/null
    killall -9 cgminer 2>/dev/null                 # the web miner is /config/bound/bin/cgminer
    sleep 1
    if [ ! -f /fpgabit/$BIT ]; then
        echo "missing /fpgabit/$BIT"; exit 1
    fi
    if [ -z "`lsmod | grep samc_spidev2`" ]; then
        insmod /lib/modules/`uname -r`/kernel/drivers/samc/samc_spidev2.ko
    fi
    echo "loading $BIT into the FPGAs ..."
    if [ -x /config/bound/bin/bound-loadfpga ]; then
        /config/bound/bin/bound-loadfpga $BIT || { echo "bound-loadfpga failed (see /tmp/bound_loadfpga.log)"; exit 1; }
    else
        loadfpga $BIT || { echo "loadfpga failed"; exit 1; }
    fi
    sleep 1
    setup_pwm
}

case "$1" in
    bench)
        load_bitstream
        $DIR/bound-miner ${PWM_PERIOD_NS:+--pwm-period $PWM_PERIOD_NS} `fan_opts` --bench ${2:-60}
        ;;
    start)
        [ -f $DIR/bound.conf ] || { echo "create $DIR/bound.conf first"; exit 1; }
        load_bitstream
        screen -dmS bound sh -c "$DIR/bound-miner `cat $DIR/bound.conf` 2>&1 | tee /tmp/bound.log"
        echo "mining in background: sh $0 log   (log also in /tmp/bound.log)"
        ;;
    stop)
        pause_monitor
        killall bound-miner cgminer 2>/dev/null
        echo "stopped (FPGAs stop by themselves within the watchdog time)"
        ;;
    restore)
        killall bound-miner 2>/dev/null
        resume_monitor
        echo "monitor resumed: the coin chosen on the web page restarts within about 30 s"
        ;;
    log)
        screen -r bound
        ;;
    fan-info)
        echo "uname: `uname -r`"
        ls -l /sys/class/pwm/
        for f in $PWM_DIR/*; do [ -f $f ] && echo "$f = `cat $f 2>/dev/null`"; done
        echo "tachometer IRQs ($TACH_IRQS):"
        for i in $TACH_IRQS; do grep "^ *$i:" /proc/interrupts; done
        echo "all gpio interrupts:"
        grep -i gpio /proc/interrupts
        ;;
    fan)
        [ -n "$2" ] || { echo "usage: $0 fan PCT"; exit 1; }
        if [ -n "`pidof bound-miner`" ] || ps w | grep -v grep | grep -q "$DIR/bin/cgminer"; then
            echo "bound-miner is running and controls the fan: stop it first (sh $0 stop)"; exit 1; fi
        pause_monitor
        setup_pwm >/dev/null
        per=`cat $PWM_DIR/period_ns`
        duty=$(( per * $2 / 100 ))
        echo $duty > $PWM_DIR/duty_ns
        [ -f $PWM_DIR/run ] && echo 1 > $PWM_DIR/run
        echo "fan: duty $duty / $per ns ($2 %), measuring for 10 s ..."
        sleep 5
        a=`tach_counts`; sleep 5; b=`tach_counts`
        set -- $a; a1=$1; a2=$2
        set -- $b; b1=$1; b2=$2
        for k in 1 2; do
            eval x=\$a$k; eval y=\$b$k
            if [ "$x" = "-1" ]; then echo "  tach $k: IRQ not found"; else echo "  tach $k: $(( (y - x) * 6 )) rpm"; fi
        done
        ;;
    *)
        echo "usage: $0 bench [seconds] | start | stop | restore | log | fan-info | fan PCT"
        ;;
esac
