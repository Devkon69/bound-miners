#!/bin/sh
# bound_hook.sh - BOUND (BoundHash) from the BlackMiner web interface, like the original coins.
#
# The root file system of the control board is in RAM and comes back from flash at every
# boot, so /etc/init.d/cgminer.sh cannot be changed for good. This script patches the RAM
# copy instead, at every boot: /etc/init.d/network.sh sources /config/network.conf, where the
# installer added the line
#   [ -x /config/bound/bound_hook.sh ] && /config/bound/bound_hook.sh boot ... # bound_hook
# With the patch, coin-type "bound" (Pool/Miner page) loads /fpgabit/fpgaminer_top_bound.bit and
# starts /config/bound/bin/cgminer (bound-miner) instead of the vendor cgminer. Other coins are
# not affected. Deleting the line from network.conf (or the /config/bound folder) undoes it.
#
# It works next to the QTC hook (qtc_hook.sh): each one adds only its own line to
# cgminer.sh (BOUND-HOOK / QTC-HOOK), and BOUND does not touch the line QTC changes.
#
#   bound_hook.sh boot     patch, then start BOUND if it is the selected coin and is not running
#   bound_hook.sh patch    only patch /etc/init.d/cgminer.sh and the Miner Status page
#   bound_hook.sh status   show the installation state
DIR=${BOUND_DIR:-/config/bound}
CG=${BOUND_CG:-/etc/init.d/cgminer.sh}
INC=$DIR/cgminer_hook.inc
CONF=${BOUND_CONF:-/config/cgminer.conf}
LOG=/tmp/bound_hook.log

coin_type() {
    grep '"coin-type"' $CONF 2>/dev/null | awk '{split($0 ,a,"[\"]");print a[4]}'
}

bound_running() {
    ps w 2>/dev/null | grep -v grep | grep -q "$DIR/bin/cgminer"
}

# after the line that reads coin-type: coin bound -> our program; loadfpga of the generic
# "not support coin type" branch -> fpgaminer_top_bound.bit (through a shell function, so the
# vendor line, or the one already changed by the QTC hook, stays as it is)
patch_cgminer() {
    [ -f "$CG" ] || { echo "no $CG"; return 1; }
    [ -f "$INC" ] || { echo "missing $INC"; return 1; }
    if grep -q BOUND-HOOK "$CG"; then
        # already patched: by this version of the hook line? (after an upgrade the RAM copy of
        # cgminer.sh still has the old line until the reboot: replace it)
        if [ "`grep BOUND-HOOK "$CG" | head -1 | sed 's/^[[:space:]]*//'`" = "`sed 's/^[[:space:]]*//' "$INC" | head -1`" ]; then
            echo "cgminer.sh already patched"; return 0
        fi
        echo "cgminer.sh patched with an older hook line: replacing it"
        sed '/BOUND-HOOK/d' "$CG" > /tmp/cgminer.sh.bound0 && cat /tmp/cgminer.sh.bound0 > "$CG"; rm -f /tmp/cgminer.sh.bound0
    fi
    sed -e "/coin_type=\`echo \$ct_string/r $INC" "$CG" > /tmp/cgminer.sh.bound || return 1
    n=`grep -c BOUND-HOOK /tmp/cgminer.sh.bound`
    if [ "$n" -lt 1 ] || ! grep -q "loadfpga fpgaminer_top" /tmp/cgminer.sh.bound; then
        echo "this cgminer.sh is not the expected one ($n changes): not patched"
        rm -f /tmp/cgminer.sh.bound; return 1
    fi
    cat /tmp/cgminer.sh.bound > "$CG" && rm -f /tmp/cgminer.sh.bound
    echo "cgminer.sh patched ($n changes)"
}

# Miner Status page (also in RAM): status.sed makes its "Temp(Chip)" column show temp2_N (the
# temperature of every FPGA; miners that do not send it keep the old value) and adds
# Accepted / Rejected / HW errors next to the hashrate (status_tiles.inc). The change is the
# same one the QTC package makes and uses the same marker, so it is done only once.
ST=${BOUND_ST:-/www/pages/cgi-bin/minerStatus.cgi}
patch_status() {
    [ -f "$ST" ] || return 0
    if grep -q QTC-HOOK "$ST"; then echo "minerStatus.cgi already patched"; return 0; fi
    [ -f $DIR/status.sed ] && [ -f $DIR/status_tiles.inc ] || { echo "missing status.sed"; return 0; }
    sed "s|@TILES@|$DIR/status_tiles.inc|" $DIR/status.sed > /tmp/bound_status.sed
    sed -f /tmp/bound_status.sed "$ST" > /tmp/minerStatus.cgi.bound
    n=`grep -c QTC-HOOK /tmp/minerStatus.cgi.bound`
    if [ "$n" -eq 5 ]; then cat /tmp/minerStatus.cgi.bound > "$ST"; echo "minerStatus.cgi patched"
    else echo "minerStatus.cgi not the expected one ($n changes): not patched"; fi
    rm -f /tmp/minerStatus.cgi.bound /tmp/bound_status.sed
}

# Frequency page (also in RAM): day / night profiles and chip temperatures (bm_freqprof, shared by
# all the coin packages). bm_freqprof.cgi goes to /www/pages/cgi-bin, minerAdvanced.cgi prints
# /config/bm_freqprof/freqprof.html before </body>. Whichever package runs first patches the page.
FP=${BOUND_FP:-/config/bm_freqprof}
FA=${BOUND_FA:-/www/pages/cgi-bin/minerAdvanced.cgi}
patch_freqpage() {
    [ -f "$FA" ] && [ -f $FP/bm_freqprof.cgi ] && [ -f $FP/freqprof.html ] || return 0
    cat $FP/bm_freqprof.cgi > `dirname $FA`/bm_freqprof.cgi && chmod 755 `dirname $FA`/bm_freqprof.cgi
    if grep -q FREQPROF-HOOK "$FA"; then echo "minerAdvanced.cgi already patched"; return 0; fi
    n=`grep -c '^</body>' "$FA"`
    [ "$n" = 1 ] || { echo "minerAdvanced.cgi not the expected one ($n </body>): not patched"; return 0; }
    sed -e 's|^</body>|EOT\
[ -f '$FP'/freqprof.html ] \&\& cat '$FP'/freqprof.html # FREQPROF-HOOK\
cat <<EOT\
</body>|' "$FA" > /tmp/minerAdvanced.cgi.fp
    if [ "`grep -c FREQPROF-HOOK /tmp/minerAdvanced.cgi.fp`" = 1 ] && sh -n /tmp/minerAdvanced.cgi.fp; then
        cat /tmp/minerAdvanced.cgi.fp > "$FA"; echo "minerAdvanced.cgi patched (frequency profiles)"
    else echo "minerAdvanced.cgi: patch failed, left as it is"; fi
    rm -f /tmp/minerAdvanced.cgi.fp
}

case "$1" in
    boot)
        exec >>$LOG 2>&1 </dev/null
        echo "`date` boot hook (coin `coin_type`)"
        # the QTC hook (if installed) starts at the same moment and rewrites the same files:
        # let it finish first
        sleep 3
        patch_status
        patch_freqpage
        patch_cgminer || exit 0
        [ "`coin_type`" = "bound" ] || exit 0
        # Normally init starts cgminer.sh after this hook, or the vendor monitor does within
        # 30 s when nothing runs. Only if cgminer.sh ran before the patch, the vendor cgminer is
        # running with coin bound: then restart once. (No restart otherwise: a second start while
        # the first loads the bitstream would disturb it.)
        sleep 40
        if ps w | grep -v grep | grep -q "/usr/bin/cgminer " && ! bound_running; then
            echo "vendor cgminer running with coin bound: restarting"
            /etc/init.d/cgminer.sh restart
        else
            echo "nothing to do (bound-miner `bound_running && echo running || echo 'not running yet'`)"
        fi
        ;;
    patch)
        patch_status
        patch_freqpage
        patch_cgminer
        ;;
    status)
        echo "selected coin:      `coin_type`"
        if grep -q BOUND-HOOK "$CG" 2>/dev/null; then echo "cgminer.sh:         patched"; else echo "cgminer.sh:         NOT patched"; fi
        if grep -q bound_hook /config/network.conf 2>/dev/null; then echo "boot hook:          in /config/network.conf"; else echo "boot hook:          MISSING in /config/network.conf"; fi
        ls -l /fpgabit/fpgaminer_top_bound.bit /fpgabit/cgminer_bound.conf $DIR/bin/cgminer 2>&1
        if bound_running; then echo "bound-miner:          running (log: /tmp/bound.log)"; else echo "bound-miner:          not running"; fi
        $DIR/bin/cgminer --help 2>/dev/null | head -1
        ;;
    *)
        echo "usage: $0 boot | patch | status"
        ;;
esac
exit 0
