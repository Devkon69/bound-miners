#!/bin/sh
# bm_hooks.sh - shared boot hook for the BlackMiner coin packages (QTC, MDS, NOID, CSD...)
BMVER=2
#
# Every coin package patches the RAM copies of /etc/init.d/cgminer.sh and minerStatus.cgi at
# boot. Started all together they wrote the same files at the same moment and broke them, so
# /config/network.conf now has a single line, and this script starts the coin hooks
# (/config/<coin>/<coin>_hook.sh) one at a time.
# The Network web page rewrites network.conf from scratch: at boot this script also patches
# (in RAM) set_network_conf.cgi, so the page puts the line back every time it saves.
#
#   bm_hooks.sh boot      from network.conf: patch the CGI, fix network.conf, run the hooks in turn
#   bm_hooks.sh netconf   from set_network_conf.cgi: put the line back in network.conf
#   bm_hooks.sh install   from the package runme.sh: patch the CGI and fix network.conf
#   bm_hooks.sh status
NC=/config/network.conf
CGI=/www/pages/cgi-bin/set_network_conf.cgi
LINE='[ -x /config/bm_hooks.sh ] && /config/bm_hooks.sh boot </dev/null >/dev/null 2>&1 & return 0 # bm_hooks # qtc_hook # mds_hook # noid_hook # csd_hook'
LOG=/tmp/bm_hooks.log

# keep the user's settings, drop every hook line, put ours at the end. The "return 0" stops
# network.sh from reading further, so old per-coin lines added below it later do nothing.
fix_netconf() {
  [ -f $NC ] || return
  grep -v -e '_hook' -e 'bm_hooks' $NC > $NC.tmp 2>/dev/null
  [ -n "`tail -c 1 $NC.tmp`" ] && echo >> $NC.tmp
  echo "$LINE" >> $NC.tmp
  if cmp -s $NC.tmp $NC 2>/dev/null; then rm -f $NC.tmp; else mv -f $NC.tmp $NC; sync; fi
}

patch_cgi() {
  [ -f $CGI ] || return
  grep -q BM-HOOKS $CGI && return
  sed -i '/^\/etc\/init.d\/network.sh/i [ -x /config/bm_hooks.sh ] && /config/bm_hooks.sh netconf # BM-HOOKS' $CGI
  grep -q BM-HOOKS $CGI && echo "set_network_conf.cgi patched" || echo "set_network_conf.cgi not the expected one: not patched"
}

# a hook patches first, then may wait (sleep 40) to restart its miner: wait for it at most
# 10 s, enough for the patch, then go on with the next one
run_one() {
  echo "`date` $1" >> $LOG
  $1 boot </dev/null >>$LOG 2>&1 &
  p=$!; n=0
  while kill -0 $p 2>/dev/null && [ $n -lt 10 ]; do sleep 1; n=$((n+1)); done
}

case "$1" in
  boot)
    [ -f /tmp/bm_hooks.done ] && exit 0
    : > /tmp/bm_hooks.done
    echo "`date` bm_hooks $BMVER boot" >> $LOG
    patch_cgi >> $LOG 2>&1
    fix_netconf
    for h in /config/*/*_hook.sh; do
      [ -x "$h" ] && run_one "$h"
    done
    ;;
  netconf) fix_netconf ;;
  install) patch_cgi; fix_netconf ;;
  status)
    echo "bm_hooks:           version $BMVER"
    grep -q bm_hooks $NC 2>/dev/null && echo "network.conf:       ok" || echo "network.conf:       line MISSING"
    grep -q BM-HOOKS $CGI 2>/dev/null && echo "Network page:       patched" || echo "Network page:       NOT patched"
    echo "coin hooks:         `ls /config/*/*_hook.sh 2>/dev/null | tr '\n' ' '`"
    ;;
  *) echo "usage: $0 boot | netconf | install | status" ;;
esac
exit 0
