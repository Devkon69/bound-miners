s/^echo "<li class=\\"layui-col-xs4\\"/echo "<li class=\\"layui-col-xs2\\"/
/bb_temp2=\${bb_stats_tmp#\*temp1=}/{
s/bb_temp2=.*/bb_temp2=${bb_stats_tmp#*temp2_1=}; [ "$bb_temp2" = "$bb_stats_tmp" ] \&\& bb_temp2=$bb_temp # QTC-HOOK/
n
s/bb_temp2=.*/bb_temp2=${bb_temp2%%,*}/
}
/bb_temp2=\${bb_stats_tmp#\*temp2=}/{
s/bb_temp2=.*/bb_temp2=${bb_stats_tmp#*temp2_2=}; [ "$bb_temp2" = "$bb_stats_tmp" ] \&\& bb_temp2=$bb_temp # QTC-HOOK/
n
s/bb_temp2=.*/bb_temp2=${bb_temp2%%,*}/
}
/bb_temp2=\${bb_stats_tmp#\*temp3=}/{
s/bb_temp2=.*/bb_temp2=${bb_stats_tmp#*temp2_3=}; [ "$bb_temp2" = "$bb_stats_tmp" ] \&\& bb_temp2=$bb_temp # QTC-HOOK/
n
s/bb_temp2=.*/bb_temp2=${bb_temp2%%,*}/
}
/bb_temp2=\${bb_stats_tmp#\*temp4=}/{
s/bb_temp2=.*/bb_temp2=${bb_stats_tmp#*temp2_4=}; [ "$bb_temp2" = "$bb_stats_tmp" ] \&\& bb_temp2=$bb_temp # QTC-HOOK/
n
s/bb_temp2=.*/bb_temp2=${bb_temp2%%,*}/
}
/cite id=\\"bb_ghsav\\"/{
n
n
r @TILES@
}
