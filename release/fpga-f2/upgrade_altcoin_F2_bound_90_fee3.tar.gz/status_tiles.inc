# QTC-HOOK: shares and hardware errors next to the hashrate (6 tiles of xs2: the box is one row high)
echo "<li class=\"layui-col-xs2\"><a class=\"x-admin-backlog-body\"><h3 class=\"lang\" key=\"Accepted\">Accepted</h3><p><cite id=\"bb_accepted\">${bb_accepted}</cite></p></a></li>"
echo "<li class=\"layui-col-xs2\"><a class=\"x-admin-backlog-body\"><h3 class=\"lang\" key=\"Rejected\">Rejected</h3><p><cite id=\"bb_rejected\">${bb_rejected} / stale ${bb_stale}</cite></p></a></li>"
echo "<li class=\"layui-col-xs2\"><a class=\"x-admin-backlog-body\"><h3>HW errors</h3><p><cite id=\"bb_hwerr\">${bb_hw}</cite></p></a></li>"
