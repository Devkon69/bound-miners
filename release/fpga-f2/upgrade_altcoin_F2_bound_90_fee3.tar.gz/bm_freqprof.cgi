#!/bin/sh
# bm_freqprof.cgi - day / night frequency profiles for the BlackMiner Frequency page (all coins).
# Installed in RAM at every boot by the coin hook (/www/pages/cgi-bin/bm_freqprof.cgi) from
# /config/bm_freqprof/bm_freqprof.cgi. Used by the script freqprof.html added to minerAdvanced.cgi.
#
#   GET  ?get       JSON: coin, active profile, both profiles, chip temperatures and chips per board
#   GET  ?temps     JSON: chip temperatures only (the page refreshes them every 10 s)
#   POST            active=day|night & day0= & day1= & day2= & night0= & night1= & night2= [& apply=1]
#                   board values = 6 clocks in MHz separated by ':' (one per chip)
#                   saves the profiles; with apply=1 writes the active one into cgminer.conf and
#                   tells the miner (SIGHUP: applied at once by miners that support it, otherwise
#                   the miner is restarted by cgminer.sh)
# Profiles: /config/bm_freqprof/<coin>.prof   Log: /tmp/bm_freqprof.log
CONF=${BMFP_CONF:-/config/cgminer.conf}
DIR=${BMFP_DIR:-/config/bm_freqprof}
API=${BMFP_API:-cgminer-api}
PIDDIR=${BMFP_PIDDIR:-/tmp}
LOG=/tmp/bm_freqprof.log

printf "Content-type: application/json\r\nCache-Control: no-cache\r\n\r\n"

coin=`grep '"coin-type"' $CONF 2>/dev/null | awk '{split($0 ,a,"[\"]");print a[4]}'`
case "$coin" in ""|*[!A-Za-z0-9_-]*) coin=unknown ;; esac
PROF=$DIR/$coin.prof

# board N clocks from cgminer.conf ("board0-freq" : "250:250:...") or the global freq
conf_board() {
    v=`grep "\"board$1-freq\"" $CONF 2>/dev/null | awk '{split($0 ,a,"[\"]");print a[4]}'`
    if [ -z "$v" ] || ! grep -q '"freq-ctrl" *: *true' $CONF 2>/dev/null; then
        f=`grep '"freq"' $CONF 2>/dev/null | awk '{split($0 ,a,"[\"]");print a[4]}'`
        [ -n "$f" ] || f=0
        v="$f:$f:$f:$f:$f:$f"
    fi
    echo "$v"
}

prof_get() {   # prof_get KEY  -> value from the profile file, or the current clocks
    v=""
    [ -f $PROF ] && v=`sed -n "s/^$1=//p" $PROF | head -n 1`
    if [ -z "$v" ]; then
        case "$1" in
            active) v=day ;;
            day*) v=`conf_board ${1#day}` ;;
            night*) v=`conf_board ${1#night}` ;;
        esac
    fi
    echo "$v"
}

valid_board() {   # 1..6 clocks 50..450 MHz (integers or one decimal), separated by ':'
    echo "$1" | grep -Eq '^[0-9]{2,3}(\.[0-9]+)?(:[0-9]{2,3}(\.[0-9]+)?){0,5}$' || return 1
    for x in `echo "$1" | tr ':' ' '`; do
        i=${x%%.*}; [ "$i" -ge 50 ] && [ "$i" -le 450 ] || return 1
    done
    return 0
}

temps_json() {
    st=`$API -o stats 2>/dev/null`
    printf '"temps":['
    for i in 1 2 3; do
        t=`echo "$st" | sed -n "s/.*[,|]temp2_$i=\([^,|]*\).*/\1/p" | head -n 1`
        case "$t" in *[!0-9\ .-]*) t="" ;; esac
        [ $i -gt 1 ] && printf ','
        printf '"%s"' "$t"
    done
    printf '],"acn":['
    for i in 1 2 3; do
        a=`echo "$st" | sed -n "s/.*[,|]chain_acn$i=\([0-9]*\).*/\1/p" | head -n 1`
        [ -n "$a" ] || a=0
        [ $i -gt 1 ] && printf ','
        printf '%s' "$a"
    done
    printf ']'
}

if [ "$REQUEST_METHOD" = "POST" ]; then
    read -r body
    body=`echo "$body" | sed 's/%3A/:/g; s/%3a/:/g'`
    act=""; apply=0
    for kv in `echo "$body" | tr '&' ' '`; do
        k=${kv%%=*}; v=${kv#*=}
        case "$k" in
            active) case "$v" in day|night) act=$v ;; *) echo '{"ok":false,"error":"profilo non valido"}'; exit 0 ;; esac ;;
            apply) [ "$v" = 1 ] && apply=1 ;;
            day0|day1|day2|night0|night1|night2)
                valid_board "$v" || { echo "{\"ok\":false,\"error\":\"valore non valido in $k (MHz 50..450 separati da :)\"}"; exit 0; }
                eval "p_$k=\$v" ;;
        esac
    done
    [ -n "$act" ] || act=`prof_get active`
    mkdir -p $DIR
    {
        echo "active=$act"
        for k in day0 day1 day2 night0 night1 night2; do
            eval "v=\$p_$k"; [ -n "$v" ] || v=`prof_get $k`
            echo "$k=$v"
        done
    } > $PROF.new && mv -f $PROF.new $PROF
    msg="profili salvati"
    if [ $apply = 1 ]; then
        # the active profile into cgminer.conf (lines written by set_miner_conf.cgi or the package)
        if ! grep -q '"coin-type"' $CONF; then echo '{"ok":false,"error":"cgminer.conf senza coin-type"}'; exit 0; fi
        b0=`prof_get ${act}0`; b1=`prof_get ${act}1`; b2=`prof_get ${act}2`
        awk -v b0="$b0" -v b1="$b1" -v b2="$b2" '
            /"freq-ctrl"/ || /"board[0-9]-freq"/ { next }
            /"coin-type"/ { print "\"freq-ctrl\" : true,"; print "\"board0-freq\" : \"" b0 "\",";
                            print "\"board1-freq\" : \"" b1 "\","; print "\"board2-freq\" : \"" b2 "\"," }
            { print }' $CONF > $CONF.fp && cat $CONF.fp > $CONF && rm -f $CONF.fp
        [ -d /config/user_confs ] && cp $CONF /config/user_confs/cgminer_$coin.conf
        sync
        pf=$PIDDIR/$coin-miner.pid; pid=""; bin=${BMFP_BIN:-/config/$coin/bin/cgminer}
        [ -f $pf ] && pid=`cat $pf 2>/dev/null`
        if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null && grep -q "$bin" /proc/$pid/cmdline 2>/dev/null; then
            kill -HUP "$pid"; msg="profilo $act applicato (frequenze cambiate senza riavvio)"
        else
            ( /etc/init.d/cgminer.sh restart >/dev/null 2>&1 & ); msg="profilo $act applicato (miner riavviato)"
        fi
        echo "`date` $coin: $msg ($b0 | $b1 | $b2)" >> $LOG
    fi
    echo "{\"ok\":true,\"msg\":\"$msg\",\"active\":\"$act\"}"
    exit 0
fi

case "$QUERY_STRING" in
    temps*) printf '{'; temps_json; printf '}\n' ;;
    *)
        printf '{"coin":"%s","active":"%s",' "$coin" "`prof_get active`"
        for k in day0 day1 day2 night0 night1 night2; do printf '"%s":"%s",' $k "`prof_get $k`"; done
        temps_json
        printf '}\n' ;;
esac
exit 0
