#!/bin/sh
# runme.sh - BOUND (BoundHash) for BlackMiner F2, installed from the web page Upgrade
# (System Upgrade), like the vendor coin packages. upgrade.cgi runs it from the folder the
# package was unpacked into; whatever it writes on stderr is shown as "upgrade failed"
# (and the miner is not rebooted), so every normal message goes to the install log.
#
# Installs:
#   /fpgabit/fpgaminer_top_bound.bit, /fpgabit/cgminer_bound.conf   (coin "bound" in the web list)
#   /config/bound/bin/cgminer        bound-miner (named cgminer for the vendor start/stop scripts)
#   /config/bound/bin/bound-loadfpga   bitstream loader (DONE low + INIT_B high = loaded)
#   /config/bound/bound_hook.sh        boot hook (see the comment in it), called from network.conf
#   /config/bm_hooks.sh         shared boot hook of all the coin packages (one line in network.conf)
#   /config/bound/status.sed, status_tiles.inc   additions to the Miner Status page
#   /config/bound/bound_start.sh       manual tools (bench, fan test) over ssh
#   /config/bound/extra.conf, fan.conf  kept if already there
LOG=/config/bound/install.log
mkdir -p /config/bound/bin 2>/dev/null
exec 3>&2 >>$LOG 2>&1
fail() { echo "FAILED: $*"; echo "BOUND: $* (log: $LOG)" >&3; sync; exit 0; }
echo "===== `date` BOUND install (F2 package, bound-miner 1.1, bound-loadfpga) from `pwd`"

for f in bound-miner bound-loadfpga fpgaminer_top_bound.bit cgminer_bound.conf bound_hook.sh cgminer_hook.inc status.sed status_tiles.inc bound_start.sh bm_hooks.sh bm_freqprof.cgi freqprof.html md5sums.txt; do
    [ -f "$f" ] || fail "incomplete package: $f missing"
done
while read sum name; do                          # md5sum -c is not in every BusyBox
    got=`md5sum "$name" | awk '{print $1}'`
    [ "$got" = "$sum" ] || fail "damaged package: $name (md5 $got, expected $sum)"
done < md5sums.txt
echo "package md5 ok"

[ -e /dev/mtd10 ] && grep -q " /fpgabit " /proc/mounts || fail "/fpgabit (NAND) not mounted: this package is for the NAND firmware"
grep -q " /config " /proc/mounts || fail "/config not mounted"

# (BusyBox 1.20 of the F2 has no "head -c": dd reads the header)
# right package for this machine? Compare the FPGA IDCODE of our bitstream with the one of
# the vendor bitstreams already in /fpgabit (they are made for the chips on these boards).
hexhead() { dd if="$1" bs=2048 count=1 2>/dev/null | { hexdump -v -e '1/1 "%02x"' 2>/dev/null || od -An -tx1 -v 2>/dev/null; } | tr -d ' \n'; }
idcode() { hexhead "$1" | grep -o '30018001........' | head -1 | cut -c9-16; }
want=03682093
mine=`idcode fpgaminer_top_bound.bit`
[ -z "$mine" ] || [ "$mine" = "$want" ] || fail "damaged package: bitstream IDCODE $mine, expected $want"
seen=""
for b in /fpgabit/fpgaminer_top*.bit; do
    [ -f "$b" ] || continue
    case "$b" in *_bound.bit|*_rigor.bit|*_prox.bit|*_csd.bit|*_qtc.bit|*_noid.bit|*_mds.bit|*_ting.bit|*_walk.bit) continue;; esac
    id=`idcode "$b"`
    [ -n "$id" ] && { seen="$id"; echo "vendor bitstream $b: IDCODE $id"; break; }
done
if [ -n "$seen" ] && [ "$seen" != "$want" ]; then
    case "$seen" in
        03682093) other="F2 (XC7VX415T)";; 03651093) other="F1 / F1 Plus (XC7K325T)";; 03752093) other="F1 Ultra (XC7K420T)";; *) other="IDCODE $seen";;
    esac
    fail "this package is for the F2 (XC7VX415T), but this machine has the FPGAs of a $other: use the package for that machine (nothing installed)"
fi
[ -n "$seen" ] || echo "no vendor bitstream to compare the FPGA type with: installing the F2 package as chosen"

# the boot hook needs network.sh to source /config/network.conf as a shell script
NS=/etc/init.d/network.sh
echo "--- $NS"; cat $NS
echo "--- rc links"; ls -l /etc/rc*.d 2>/dev/null | grep -E "network|cgminer"
if grep -qE '^[[:space:]]*(\.|source)[[:space:]]+"?/config/network\.conf' $NS; then
    echo "network.sh sources /config/network.conf"
elif grep -q network.conf $NS && grep -qE '^[[:space:]]*(\.|source)[[:space:]]' $NS; then
    echo "network.sh seems to source network.conf through a variable"
else
    fail "$NS does not source /config/network.conf on this firmware: automatic start not possible, nothing installed"
fi
[ -f /config/network.conf ] || fail "/config/network.conf missing: save the Network page once, then retry"

# bitstream: copy next to the old one, then replace (if there is no room, drop the old one first)
df -k /fpgabit
cp fpgaminer_top_bound.bit /fpgabit/.bound.bit.new && sync && \
    [ "`md5sum /fpgabit/.bound.bit.new | awk '{print $1}'`" = "`awk '$2 == "fpgaminer_top_bound.bit" {print $1}' md5sums.txt`" ]
if [ $? -ne 0 ]; then
    rm -f /fpgabit/.bound.bit.new
    if [ -f /fpgabit/fpgaminer_top_bound.bit ]; then
        echo "no room for two copies: removing the old BOUND bitstream first"
        rm -f /fpgabit/fpgaminer_top_bound.bit; sync
        cp fpgaminer_top_bound.bit /fpgabit/.bound.bit.new && sync && \
            [ "`md5sum /fpgabit/.bound.bit.new | awk '{print $1}'`" = "`awk '$2 == "fpgaminer_top_bound.bit" {print $1}' md5sums.txt`" ]
        ok=$?
    else ok=1; fi
    if [ $ok -ne 0 ]; then
        rm -f /fpgabit/.bound.bit.new; sync
        free=`df -k /fpgabit | awk 'NR == 2 {print int($4 / 1024)}'`
        fail "not enough space in /fpgabit (free ${free} MB, needed about 12 MB): remove a coin you do not use with the remove button of the Pool/Miner page, then retry"
    fi
fi
mv -f /fpgabit/.bound.bit.new /fpgabit/fpgaminer_top_bound.bit || fail "cannot write /fpgabit/fpgaminer_top_bound.bit"
cp -f cgminer_bound.conf /fpgabit/cgminer_bound.conf || fail "cannot write /fpgabit/cgminer_bound.conf"
echo "bitstream and coin configuration installed"

# program: replaced by rename, so a running copy is not disturbed
cp bound-miner /config/bound/bin/cgminer.new && chmod 755 /config/bound/bin/cgminer.new && \
    mv -f /config/bound/bin/cgminer.new /config/bound/bin/cgminer || { rm -f /config/bound/bin/cgminer.new; fail "cannot write /config/bound/bin/cgminer (is /config full?)"; }
rm -f /config/bound/bound-miner && ln -s bin/cgminer /config/bound/bound-miner
# our bitstream loader (judges the load by INIT_B, see LEGGIMI); replaced by rename too
cp bound-loadfpga /config/bound/bin/bound-loadfpga.new && chmod 755 /config/bound/bin/bound-loadfpga.new && \
    mv -f /config/bound/bin/bound-loadfpga.new /config/bound/bin/bound-loadfpga || { rm -f /config/bound/bin/bound-loadfpga.new; fail "cannot write /config/bound/bin/bound-loadfpga"; }
echo "loader installed: `/config/bound/bin/bound-loadfpga --help | head -1`"
for f in bound_hook.sh bound_start.sh; do cp -f $f /config/bound/$f && chmod 755 /config/bound/$f || fail "cannot write /config/bound/$f"; done
for f in cgminer_hook.inc status.sed status_tiles.inc; do cp -f $f /config/bound/$f || fail "cannot write /config/bound/$f"; done
[ -f LEGGIMI.txt ] && cp -f LEGGIMI.txt /config/bound/LEGGIMI.txt
[ -f /config/bound/extra.conf ] || cp extra.conf /config/bound/extra.conf
[ -f /config/bound/fan.conf ] || cp fan.conf /config/bound/fan.conf
# an extra.conf kept from an older package: add --web-freq (the clocks of the Frequency page)
sed 's/#.*//' /config/bound/extra.conf | grep -q -- '--web-freq' || { [ -n "`tail -c 1 /config/bound/extra.conf`" ] && echo >> /config/bound/extra.conf; echo "--web-freq" >> /config/bound/extra.conf; echo "added --web-freq to /config/bound/extra.conf"; }
# BOUND-FREQ: an extra.conf kept from an older package: the clock of this bitstream
grep -q 'BOUND-FREQ' /config/bound/extra.conf || { [ -n "`tail -c 1 /config/bound/extra.conf`" ] && echo >> /config/bound/extra.conf; echo '# BOUND-FREQ: ceiling of the bitstream clock' >> /config/bound/extra.conf; echo '--freq-max 100' >> /config/bound/extra.conf; echo 'added --freq-max 100 to /config/bound/extra.conf'; }
# day / night profiles of the Frequency page (shared by all the coin packages, newest copy wins)
mkdir -p /config/bm_freqprof && cp -f bm_freqprof.cgi freqprof.html /config/bm_freqprof/ && chmod 755 /config/bm_freqprof/bm_freqprof.cgi || fail "cannot write /config/bm_freqprof"
echo "frequency profiles installed in /config/bm_freqprof"
echo "program installed: `/config/bound/bin/cgminer --help | head -1`"

# boot hook: one shared line in /config/network.conf; /config/bm_hooks.sh starts the hooks of
# all the installed coins one at a time (started together they broke cgminer.sh) and keeps the
# line when the Network page is saved. An older bm_hooks.sh is replaced, a newer one kept.
new=`sed -n 's/^BMVER=//p' bm_hooks.sh`; old=`sed -n 's/^BMVER=//p' /config/bm_hooks.sh 2>/dev/null`
if [ "${old:-0}" -lt "$new" ]; then
    cp -f bm_hooks.sh /config/bm_hooks.sh.new && chmod 755 /config/bm_hooks.sh.new && \
        mv -f /config/bm_hooks.sh.new /config/bm_hooks.sh || { rm -f /config/bm_hooks.sh.new; fail "cannot write /config/bm_hooks.sh"; }
    echo "bm_hooks.sh $new installed"
else
    echo "bm_hooks.sh ${old} already installed"
fi
/config/bm_hooks.sh install
cat /config/network.conf
/config/bound/bound_hook.sh patch || fail "the cgminer.sh of this firmware is not the expected one"
sync
echo "done: after the reboot choose bound on the Pool/Miner page: pool stratum+tcp://IP_OF_YOUR_PC:7340 (the bridge next to your node), user YOUR_BOUND_ADDRESS.worker"
exit 0
