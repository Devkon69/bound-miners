#!/bin/sh
# bm-fan.sh 0.4 - ventole a 4 fili della carrier BlackMiner sulla BeagleBone Black (cape-universal)
#
#   sudo bm-fan.sh setup [PERIODO_NS]  prepara PWM (P9_29, ehrpwm0B) e tachimetri (P9_18, P9_41);
#                                      scrive in /run/blackminer-fan.args le opzioni per il miner
#   sudo bm-fan.sh info                stato di PWM, tachimetri e pinmux
#   sudo bm-fan.sh set PCT             ventole a PCT % e misura dei giri (miner fermo)
#
# Periodo PWM (PWM_PERIOD_NS, 40000 = 25 kHz) letto da $BM_FAN_CONF, poi dal primo fan.conf trovato in
# /config/{noid,mds,verus,aln,csd,qtc,quip}/ (0.4: unisce le 0.3.2 di Verus e ALN, aggiunge CSD, QTC, Quip).
# Lavora solo a sistema avviato: non tocca uEnv.txt, overlay o dtb.
ARGS_FILE=/run/blackminer-fan.args
PWM_PERIOD_NS=40000
for f in "$BM_FAN_CONF" /config/noid/fan.conf /config/mds/fan.conf /config/verus/fan.conf /config/aln/fan.conf /config/csd/fan.conf /config/qtc/fan.conf /config/quip/fan.conf; do
    [ -n "$f" ] && [ -f "$f" ] && { . "$f"; break; }
done
[ "$(id -u)" = 0 ] || { echo "lancia con sudo"; exit 1; }

# canale B (1) di ehrpwm0 = 48300200.pwm; kernel TI 4.19: pwm-N:1, kernel standard: pwmchipN/pwm1
pwm_dir() {
    for c in /sys/class/pwm/pwmchip*; do
        case "$(readlink -f $c)" in *48300200.pwm*) ;; *) continue ;; esac
        n=${c##*pwmchip}
        for d in $c/pwm1 $c/pwm-$n:1 /sys/class/pwm/pwm-$n:1; do [ -f $d/period ] && { echo $d; return 0; }; done
        echo 1 > $c/export 2>/dev/null; sleep 0.2
        for d in $c/pwm1 $c/pwm-$n:1 /sys/class/pwm/pwm-$n:1; do [ -f $d/period ] && { echo $d; return 0; }; done
    done
    return 1
}

# IRQ (in /proc/interrupts) del gpio sysfs numero $1, dopo aver impostato edge=rising
tach_irq() {
    g=$1; d=/sys/class/gpio/gpio$g
    [ -d $d ] || echo $g > /sys/class/gpio/export 2>/dev/null
    [ -d $d ] || return 1
    echo in > $d/direction 2>/dev/null
    echo none > $d/edge 2>/dev/null
    before=" $(awk '/gpiolib/ {sub(":", "", $1); printf "%s ", $1}' /proc/interrupts)"
    echo rising > $d/edge 2>/dev/null || return 1
    after=$(awk '/gpiolib/ {sub(":", "", $1); print $1}' /proc/interrupts)
    for i in $after; do
        case "$before" in *" $i "*) ;; *) echo $i; return 0 ;; esac
    done
    awk -v hw="$2" '/gpiolib/ && /44e07000|gpio-0-31/ { for (i = 3; i < NF; i++) if ($i ~ /44e07000|gpio-0-31/ && $(i+1) == hw) { sub(":", "", $1); print $1; exit } }' /proc/interrupts
}

# numero sysfs di gpio0_N (banco 0 = 44e07000.gpio; base 0 sul kernel 4.19, dinamica sui 6.x)
gpio0() {
    for c in /sys/class/gpio/gpiochip*; do
        l=$(cat $c/label 2>/dev/null)
        case "$l" in *44e07000*|gpio-0-31) echo $(( $(cat $c/base) + $1 )); return 0 ;; esac
    done
    echo $1
}

cfgpin() { command -v config-pin >/dev/null && config-pin $1 $2 >/dev/null 2>&1; }

setup() {
    per=${1:-$PWM_PERIOD_NS}
    cfgpin P9_29 pwm; cfgpin P9_18 gpio_pu; cfgpin P9_41 gpio_pu
    d=$(pwm_dir) || { echo "fan: canale PWM di P9_29 (ehrpwm0B) non trovato (serve cape-universal: config-pin P9_29 pwm)"; return 1; }
    cur=$(cat $d/period)
    if [ "$cur" != "$per" ]; then
        [ "$cur" != 0 ] && echo 0 > $d/duty_cycle
        echo $per > $d/period || echo "fan: periodo $per non accettato"
    fi
    echo $per > $d/duty_cycle                      # 100 % finche' il miner non regola
    echo 1 > $d/enable
    a=$(tach_irq $(gpio0 4) 4); b=$(tach_irq $(gpio0 20) 20)
    [ -n "$a" ] || a=-1; [ -n "$b" ] || b=-1
    echo "--pwm-path $d/duty_cycle --pwm-period $per --fan-irq $a,$b" > $ARGS_FILE
    echo "fan: PWM $d, periodo $(cat $d/period) ns, tachimetri IRQ $a,$b"
    echo "     opzioni per il miner: $(cat $ARGS_FILE)"
}

counts() {   # contatori degli IRQ $1 $2
    for i in $1 $2; do awk -v irq="$i:" '$1 == irq { print $2; f = 1 } END { if (!f) print -1 }' /proc/interrupts; done
}

case "$1" in
    setup) setup "$2" ;;
    info)
        echo "bm-fan.sh 0.4, kernel $(uname -r)"
        d=$(pwm_dir) && for f in period duty_cycle enable polarity; do echo "$d/$f = $(cat $d/$f 2>/dev/null)"; done
        [ -f $ARGS_FILE ] && echo "opzioni: $(cat $ARGS_FILE)"
        echo "interrupt gpiolib:"; grep gpiolib /proc/interrupts
        command -v config-pin >/dev/null && for p in P9_29 P9_18 P9_41; do echo "$p: $(config-pin -q $p 2>&1 | tail -1)"; done
        ;;
    set)
        [ -n "$2" ] || { echo "uso: $0 set PCT"; exit 1; }
        if pidof noid-miner mds-miner verus-miner aln-miner csd-miner qtc-miner >/dev/null; then echo "un miner sta girando e regola le ventole: fermalo prima (<moneta>_start.sh stop)"; exit 1; fi
        setup >/dev/null || exit 1
        d=$(pwm_dir); per=$(cat $d/period)
        echo $(( per * $2 / 100 )) > $d/duty_cycle
        set -- $(sed 's/.*--fan-irq //; s/,/ /' $ARGS_FILE) "$2"
        ia=$1; ib=$2; pct=$3
        echo "fan: $pct % ($(cat $d/duty_cycle) / $per ns), misuro per 10 s ..."
        sleep 5; c1=$(counts $ia $ib); sleep 5; c2=$(counts $ia $ib)
        set -- $c1 $c2
        [ "$1" = -1 ] && echo "  tach 1 (P9_18): IRQ non trovato" || echo "  tach 1 (P9_18): $(( ($3 - $1) * 6 )) rpm"
        [ "$2" = -1 ] && echo "  tach 2 (P9_41): IRQ non trovato" || echo "  tach 2 (P9_41): $(( ($4 - $2) * 6 )) rpm"
        ;;
    *) sed -n '2,10p' "$0" ;;
esac
