#!/bin/sh
# bound_run.sh - avvia bound-miner con le board trovate da bmctl e le opzioni di bound.conf (usato da bound.service)
# Ventole: se esiste /config/bound/fan.conf, bm-fan.sh prepara PWM (P9_29) e tachimetri (P9_18, P9_41)
# e aggiunge --pwm-path/--pwm-period/--fan-irq; le opzioni di bound.conf vengono dopo e hanno la precedenza.
DIR=/config/bound
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export BM_FAN_CONF=$DIR/fan.conf
OPTS=$(grep -v "^#" $DIR/bound.conf 2>/dev/null)
ARGS=""
case "$OPTS" in
    *--port*) ;;    # porte scritte a mano in bound.conf
    *) PORTS=$(bmctl detect) || { echo "nessuna hash board rilevata (bmctl detect -v)"; exit 1; }
       for p in $PORTS; do ARGS="$ARGS --port $p"; done ;;
esac
case "$OPTS" in
    *--no-fan*) ;;
    *)
        if [ -f $DIR/fan.conf ] && bm-fan.sh setup && [ -s /run/blackminer-fan.args ]; then
            ARGS="$ARGS $(cat /run/blackminer-fan.args)"
        else
            echo "ventole non gestite (manca $DIR/fan.conf o il PWM di P9_29): --no-fan"
            case "$OPTS" in *--pwm-path*) ;; *) OPTS="$OPTS --no-fan" ;; esac
        fi
        ;;
esac
exec $DIR/bound-miner $ARGS --freq-file $DIR/freq.json $OPTS "$@"
