#!/usr/bin/env python3
# bm-web.py 1.2 - interfaccia web per i miner BlackMiner sulla BeagleBone Black rev C
#
# Stato del mining (hashrate, board, FPGA, temperature, share, ventole, pool), scelta della moneta
# (NOID, MDS, Verus, ALN, CSD, QTC, QUIP: quelle installate in /config/<moneta>/), pool, indirizzo,
# ventole, avvio automatico, log, riavvio; pagina Frequenza (1.2): un riquadro per ogni chip con la sua
# temperatura sopra, profili Giorno / Notte, cambio al volo (SIGHUP al miner, che rilegge /config/<moneta>/freq.json).
# Solo libreria standard di Python 3 (Debian 10: 3.7). Gira come root (servizio bm-web).
# Scrive soltanto /config/<moneta>/<moneta>.conf (copia .prima-web la prima volta), /config/<moneta>/freq.json
# e freqprof.json, /config/quip/fan.conf e /config/bm-web/web.conf; comanda i servizi con systemctl. Non tocca uEnv.txt, overlay o dtb.
import base64, hashlib, html, json, os, re, shlex, socket, subprocess, sys, threading, time
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn

VERSION = "1.6"
ROOT = os.environ.get("BMWEB_ROOT", "")          # solo per le prove: prefisso ai percorsi
CONFIG = ROOT + "/config"
WEBCONF = CONFIG + "/bm-web/web.conf"

# moneta -> nome, algoritmo, MHz del bitstream F1 Ultra (None = frequenza non regolabile), note
COINS = [
    ("noid",  "NOID",                   "NoidHash",          275, ""),
    ("mds",   "MDS (MassStore)",        "BLAKE3",            325, ""),
    ("verus", "Verus (VRSC)",           "VerusHash 2.2",     200, "Bitstream costruito a 250 MHz e ricalibrato a 200: sopra 200 serve --overclock."),
    ("aln",   "alphanumeric (ALN)",     "alphanumeric",      250, ""),
    ("csd",   "CSD (Compute Substrate)", "sha256d CSD",       200, "Bitstream v1.1: frequenza regolabile (pacchetto csd-ultra-bbb 200 MHz, csd-ultra-bbb-250 250 MHz)."),
    ("qtc",   "QTC (Quantus)",          "Poseidon2 (qPoW)",  200, ""),
    ("ting",  "Ting (Daler DLR)",       "SHA-256 Ting",      213, "Pool: stratum+tcp://crypto-connection.net:4073, utente CONTO_TING.nome. Ponte PC (solo): IP:7730, utente nome macchina. Bitstream a 212.5 MHz: --freq-max 213 in ting.conf."),
    ("rigor", "RIGOR (ORU)",            "OpuHash (SHA3-256)", 125, "Pool: stratum+tcp://rgr.ariabrain.com:3356, utente rg1q....nome, password qualsiasi. Bitstream 4 core Keccak costruito a 175 MHz: --freq-max 175 in rigor.conf; consuma molto, parti da 125 e sali guardando le temperature."),
    ("prox",  "Proxima (PROX)",         "BLAKE2b txid",      125, "Pool: http://prox.ariabrain.com:3359, utente TOKEN.nome (token di AriaPool, mostrato una volta alla registrazione dell'indirizzo a/...). Bitstream 4 core BLAKE2b costruito a 175 MHz: --freq-max 175 in prox.conf."),
    ("bound", "BOUND",                  "BoundHash",         90, "Mining in solitaria sul proprio nodo: pool = ponte sul PC, stratum+tcp://IP_DEL_PC:7340, utente INDIRIZZO_BOUND.nome. Bitstream 7 core BoundHash costruito a 90 MHz (circa 41.7 kH/s per board): --freq-max 90 in bound.conf."),
    ("quip",  "QUIP Network",           "annealer Advantage2", None, "Il miner vero gira sul PC (Docker); sulla BBB c'e' solo il ponte TCP 4029. Ventole fisse."),
]
COIN = {c[0]: c for c in COINS}

def built_mhz(coin):
    """MHz del bitstream installato: dal LEGGIMI del pacchetto in /config/<moneta>/ (il primo "N MHz",
    es. "17 corsie a 275 MHz"), altrimenti il valore della tabella COINS."""
    b = COIN[coin][3]
    try:
        with open(CONFIG + "/%s/LEGGIMI.txt" % coin, errors="replace") as fh:
            m = re.search(r"(\d{3}) MHz", fh.read())
        if m and b:
            b = int(m.group(1))
    except OSError:
        pass
    return b
SAFE = re.compile(r"^[A-Za-z0-9._:/@+=,%~-]*$")

def run(cmd, timeout=20):
    try:
        p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout)
        return p.returncode, p.stdout.decode("utf-8", "replace")
    except Exception as e:
        return 127, str(e)

def rd(path, default=""):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read()
    except Exception:
        return default

def wr(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(text)
    os.replace(tmp, path)

# ---------------------------------------------------------------- impostazioni dell'interfaccia
def hpw(salt, pw):
    return hashlib.sha256((salt + ":" + pw).encode()).hexdigest()

def webconf():
    try:
        c = json.loads(rd(WEBCONF, "{}"))
    except Exception:
        c = {}
    if "salt" not in c:
        c["salt"] = base64.b16encode(os.urandom(8)).decode().lower()
        c["user"] = "root"; c["hash"] = hpw(c["salt"], "root"); c["default_pw"] = True
        wr(WEBCONF, json.dumps(c, indent=1)); os.chmod(WEBCONF, 0o600)
    return c

# ---------------------------------------------------------------- servizi
def installed(coin):
    return os.path.exists("%s/%s/%s_run.sh" % (CONFIG, coin, coin))

def svc_state(coin):
    _, a = run(["systemctl", "is-active", coin + ".service"], 5)
    _, e = run(["systemctl", "is-enabled", coin + ".service"], 5)
    return a.strip().splitlines()[-1] if a.strip() else "unknown", e.strip().splitlines()[-1] if e.strip() else "unknown"

def svc_since(coin):
    _, o = run(["systemctl", "show", coin + ".service", "-p", "ActiveEnterTimestampMonotonic"], 5)
    m = re.search(r"=(\d+)", o)
    if not m or m.group(1) == "0":
        return None
    try:
        up = float(rd("/proc/uptime").split()[0])
        return max(0, int(up - int(m.group(1)) / 1e6))
    except Exception:
        return None

# ---------------------------------------------------------------- lettura del log del miner
R_TOTAL = re.compile(r"total ([\d.]+) (MH/s|GH/s|TH/s|kH/s|H/s|n/s|nonces/s)")
R_SHARES = re.compile(r"shares (\d+) accepted(?: \(dev fee (\d+)\))?, (\d+) rejected, (\d+) stale")
R_BLOCKS = re.compile(r"blocks: (\d+) found, (\d+) accepted, (\d+) refused, (\d+) stale")     # ting-miner
R_FAN = re.compile(r"fan (\d+)% (-?\d+)/(-?\d+) rpm")
R_BOARD = re.compile(r"board(\d+)\(([^)]+)\) ([\d.]+) (\S+) \|(.*)$")
R_FPGA = re.compile(r" (\d+):(-?[\d.]+|nan|-nan)C (\S+) ([\d.]+)([A-Za-z/]*)")
R_INFO = re.compile(r"board(\d+)\(([^)]+)\): (\d+) FPGA(.*)")
R_MHZ = re.compile(r"(\d+(?:\.\d+)?) MHz")
R_POOL = re.compile(r"(?:pool|bridge): connecting to (\S+)")
R_AUTH = re.compile(r"(?:authorized as|logged in as|login OK as) (\S+)")
R_TIME = re.compile(r"^(\d\d:\d\d:\d\d) (.*)$")
R_QUIP = re.compile(r"board(\d+) \(([^)]+)\): (\d+) QUIP FPGA, fabric (\w+)")

def journal(coin, n=400):
    _, o = run(["journalctl", "-u", coin + ".service", "-b", "-n", str(n), "-o", "cat", "--no-pager"], 15)
    return o.splitlines()

def parse(lines):
    s = {"total": None, "unit": "", "accepted": None, "rejected": None, "stale": None, "devfee": None,
         "fan": None, "rpm": [], "boards": {}, "pool": "", "user": "", "last_share": "", "events": []}
    start = 0
    for i, l in enumerate(lines):           # solo l'ultimo avvio del miner
        if re.search(r"^(\d\d:\d\d:\d\d )?\S+-miner \d|quip-f2-bridge \d|Starting ", l):
            start = i
    for l in lines[start:]:
        m = R_TIME.match(l); body = m.group(2) if m else l; t = m.group(1) if m else ""
        mt = R_TOTAL.search(body)
        if mt and body.startswith("total"):
            s["total"] = float(mt.group(1)); s["unit"] = mt.group(2)
            ms = R_SHARES.search(body)
            if ms:
                s["accepted"], s["devfee"], s["rejected"], s["stale"] = int(ms.group(1)), ms.group(2), int(ms.group(3)), int(ms.group(4))
            mk = R_BLOCKS.search(body)
            if mk:                                  # ting: blocchi accettati dal nodo al posto delle share
                s["accepted"], s["rejected"], s["stale"] = int(mk.group(2)), int(mk.group(3)), int(mk.group(4))
            mf = R_FAN.search(body)
            if mf:
                s["fan"] = int(mf.group(1)); s["rpm"] = [int(mf.group(2)), int(mf.group(3))]
            s["updated"] = t
            continue
        mb = R_BOARD.match(body)
        if mb:
            b = s["boards"].setdefault(mb.group(1), {"idx": int(mb.group(1))})
            b["port"] = mb.group(2); b["rate"] = float(mb.group(3)); b["unit"] = mb.group(4)
            b["fpga"] = [{"k": int(x[0]), "temp": None if "nan" in x[1] else float(x[1]), "st": x[2],
                          "rate": float(x[3]), "unit": x[4] or b["unit"]} for x in R_FPGA.findall(" " + mb.group(5))]
            continue
        mi = R_INFO.match(body)
        if mi:
            b = s["boards"].setdefault(mi.group(1), {"idx": int(mi.group(1))})
            b["port"] = mi.group(2); b["nfpga"] = int(mi.group(3)); b["info"] = mi.group(4).strip(" ,")
            mz = R_MHZ.findall(mi.group(4))
            if mz:
                b["mhz"] = mz[0]
            continue
        mq = R_QUIP.search(body)
        if mq:
            b = s["boards"].setdefault(mq.group(1), {"idx": int(mq.group(1))})
            b["port"] = mq.group(2); b["nfpga"] = int(mq.group(3)); b["info"] = "fabric " + mq.group(4)
            continue
        mp = R_POOL.search(body)
        if mp:
            s["pool"] = mp.group(1)
        ma = R_AUTH.search(body)
        if ma and "devfee" not in body:
            s["user"] = ma.group(1)
        if ("share accepted" in body or "BLOCK ACCEPTED" in body) and "dev fee" not in body and "devfee" not in body:
            s["last_share"] = t
        if re.search(r"error|fail|reject|HOT|watchdog|no FPGA|not respond|timeout|refused|cannot", body, re.I) \
                and "0 rejected" not in body:
            s["events"].append(l)
    s["events"] = s["events"][-8:]
    s["boards"] = [s["boards"][k] for k in sorted(s["boards"], key=int)]
    return s

# ---------------------------------------------------------------- configurazione <moneta>.conf
VALUED = {"--pool", "--user", "--password", "--rig", "--freq", "--freq-fpga", "--fan-min", "--fan-max", "--fan"}
FLAGS = {"--overclock", "--no-fan"}

def conf_path(coin):
    return "%s/%s/%s.conf" % (CONFIG, coin, coin)

def conf_read(coin):
    raw = " ".join(l.strip() for l in rd(conf_path(coin)).splitlines() if l.strip() and not l.strip().startswith("#"))
    try:
        tok = shlex.split(raw)
    except ValueError:
        tok = raw.split()
    c = {"pools": [], "user": "", "password": "", "rig": "", "freq": "", "freq_fpga": [], "fan_min": "", "fan_max": "",
         "fan": "", "overclock": False, "no_fan": False, "extra": [], "raw": raw}
    i = 0
    while i < len(tok):
        t = tok[i]; v = tok[i + 1] if i + 1 < len(tok) else ""
        if t in VALUED and v != "":
            k = t[2:].replace("-", "_")
            if t == "--pool":
                c["pools"].append(v)
            elif t == "--freq-fpga":
                c["freq_fpga"].append(v)
            else:
                c[k] = v
            i += 2; continue
        if t in FLAGS:
            c[t[2:].replace("-", "_")] = True; i += 1; continue
        c["extra"].append(t)
        if t.startswith("--") and v and not v.startswith("--"):
            c["extra"].append(v); i += 1
        i += 1
    c["extra"] = " ".join(c["extra"])
    if coin == "quip":
        m = re.search(r"^\s*FAN_PCT=(\d+)", rd(CONFIG + "/quip/fan.conf"), re.M)
        c["fan_pct"] = m.group(1) if m else "100"
    return c

class Bad(Exception):
    pass

def num(v, lo, hi, what):
    v = str(v).strip()
    if v == "":
        return ""
    try:
        x = float(v)
    except ValueError:
        raise Bad("%s: '%s' non e' un numero" % (what, v))
    if not lo <= x <= hi:
        raise Bad("%s: %s fuori dall'intervallo %s..%s" % (what, v, lo, hi))
    return ("%d" % x) if x == int(x) else ("%g" % x)

def safe(v, what):
    v = str(v).strip()
    if not SAFE.match(v):
        raise Bad("%s: caratteri non ammessi (spazi, virgolette, ; & $ * ...) in '%s'" % (what, v))
    return v

def conf_build(coin, f):
    built = built_mhz(coin)
    out = []
    pools = [safe(p, "pool") for p in f.get("pools", []) if str(p).strip()]
    for p in pools:
        if not re.match(r"^(stratum\+(tcp|ssl|tls)|ssl|tls|tcp)://[^/]+:\d+", p) and not (coin == "ting" and re.match(r"^[^/:]+:\d+$", p)) \
                and not (coin == "prox" and re.match(r"^https?://[^/]+:\d+/?$", p)):
            raise Bad("pool '%s': formato atteso stratum+tcp://host:porta o stratum+ssl://host:porta" % p)
        out += ["--pool", p]
    if coin != "quip" and not pools:
        raise Bad("serve almeno un pool")
    user = safe(f.get("user", ""), "utente/indirizzo")
    if coin != "quip":
        if not user:
            raise Bad("manca l'indirizzo (utente)")
        if "TUO_" in user:
            raise Bad("metti il tuo indirizzo al posto di %s" % user)
        out += ["--user", user]
    for k, opt in (("password", "--password"), ("rig", "--rig")):
        v = safe(f.get(k, ""), k)
        if v:
            out += [opt, v]
    oc = bool(f.get("overclock"))
    if built and f.get("legacy_freq"):          # 1.2: le frequenze stanno in freq.json (pagina Frequenza)
        top = 400 if oc else built
        fr = num(f.get("freq", ""), 50, 400, "frequenza")
        if fr and float(fr) > top:
            raise Bad("frequenza %s MHz sopra quella del bitstream (%d): spunta 'overclock' se vuoi provarla" % (fr, built))
        if fr:
            out += ["--freq", fr]
        ff = []
        for bd, mhz in enumerate(f.get("board_freq", [])):
            mhz = num(mhz, 50, 400, "frequenza board %d" % bd)
            if mhz:
                if float(mhz) > top:
                    raise Bad("board %d: %s MHz sopra %d senza overclock" % (bd, mhz, built))
                ff += ["%d:%d:%s" % (bd, k, mhz) for k in range(6)]
        for e in str(f.get("freq_fpga_extra", "")).replace(",", " ").split():
            m = re.match(r"^(\d):(\d):(\d+(?:\.\d+)?)$", e)
            if not m:
                raise Bad("frequenza per FPGA '%s': formato BOARD:FPGA:MHz, es. 1:3:180" % e)
            if float(m.group(3)) > top or float(m.group(3)) < 50:
                raise Bad("FPGA %s: %s MHz fuori intervallo (max %d senza overclock)" % (e, m.group(3), built))
            ff.append(e)
        for e in ff:
            out += ["--freq-fpga", e]
        if oc:
            out.append("--overclock")
    if coin != "quip":
        if f.get("no_fan"):
            out.append("--no-fan")
        else:
            fx = num(f.get("fan", ""), 0, 100, "ventola fissa")
            if fx:
                out += ["--fan", fx]
            else:
                a = num(f.get("fan_min", ""), 0, 100, "ventola minima"); b = num(f.get("fan_max", ""), 0, 100, "ventola massima")
                if a and b and float(a) > float(b):
                    raise Bad("ventola minima piu' alta della massima")
                if a:
                    out += ["--fan-min", a]
                if b:
                    out += ["--fan-max", b]
    extra = str(f.get("extra", "")).split()
    for e in extra:
        safe(e, "opzioni in piu'")
    out += extra
    return " ".join(out)

def conf_save(coin, f):
    if COIN[coin][3]:
        prof_get(coin)                      # prima volta: le frequenze di <moneta>.conf passano ai profili
    line = conf_build(coin, f)
    p = conf_path(coin)
    if os.path.exists(p) and not os.path.exists(p + ".prima-web"):
        wr(p + ".prima-web", rd(p))
    wr(p, line + "\n")
    if coin == "quip":
        pct = num(f.get("fan_pct", "100"), 0, 100, "ventole") or "100"
        fp = CONFIG + "/quip/fan.conf"; t = rd(fp)
        t = re.sub(r"^\s*FAN_PCT=.*$", "FAN_PCT=" + pct, t, flags=re.M) if re.search(r"^\s*FAN_PCT=", t, re.M) else t + "FAN_PCT=%s\n" % pct
        if os.path.exists(fp):
            wr(fp, t)
    return line

# ---------------------------------------------------------------- pagina Frequenza (1.2)
NB, NF = 4, 6                                   # board e FPGA per board mostrati al massimo

def freq_path(coin):
    return "%s/%s/freq.json" % (CONFIG, coin)

def prof_path(coin):
    return "%s/%s/freqprof.json" % (CONFIG, coin)

def conf_clocks(coin):
    """frequenze scritte in <moneta>.conf (--freq, --freq-fpga B:F:MHz) come tabella board x FPGA"""
    c = conf_read(coin); built = built_mhz(coin) or 0
    base = float(c["freq"]) if c.get("freq") else built
    t = [[base] * NF for _ in range(NB)]
    for e in c.get("freq_fpga", []):
        m = re.match(r"^(\d):(\d):(\d+(?:\.\d+)?)$", e)
        if m and int(m.group(1)) < NB and int(m.group(2)) < NF:
            t[int(m.group(1))][int(m.group(2))] = float(m.group(3))
    return t

def clean(t):
    return [[("%d" % v) if v == int(v) else ("%g" % v) for v in row] for row in t]

def freq_json(t):
    d = {"freq-ctrl": True}
    for b in range(NB):
        d["board%d-freq" % b] = ":".join(clean(t)[b])
    return json.dumps(d, indent=1) + "\n"

def prof_get(coin):
    """profili salvati; la prima volta tutti e due = frequenze di <moneta>.conf (o del bitstream)"""
    try:
        p = json.loads(rd(prof_path(coin), ""))
        if p.get("active") in ("day", "night") and len(p["day"]) == NB and len(p["night"]) == NB:
            return p
    except Exception:
        pass
    t = conf_clocks(coin)
    p = {"active": "day", "day": t, "night": [row[:] for row in t]}
    wr(prof_path(coin), json.dumps(p, indent=1) + "\n")
    if not os.path.exists(freq_path(coin)):
        wr(freq_path(coin), freq_json(t))
    return p

def main_pid(coin):
    _, o = run(["systemctl", "show", coin + ".service", "-p", "MainPID"], 5)
    m = re.search(r"MainPID=(\d+)", o)
    return int(m.group(1)) if m and m.group(1) != "0" else 0

def hup_ok(coin):
    """il miner acceso e' partito con --freq-file (miner 31/10 o piu' nuovo): allora capisce SIGHUP"""
    pid = main_pid(coin)
    if not pid:
        return False
    cmd = rd("/proc/%d/cmdline" % pid).split("\0")
    return "--freq-file" in cmd and freq_path(coin).replace(ROOT, "", 1) in cmd

def temps(coin):
    """temperature per board e FPGA dall'ultima riga di stato del miner (log)"""
    st = parse(journal(coin)) if installed(coin) else {"boards": []}
    t = {}
    for b in st.get("boards", []):
        t[str(b["idx"])] = {str(f["k"]): f["temp"] for f in b.get("fpga", [])}
        t[str(b["idx"])]["n"] = b.get("nfpga") or len(b.get("fpga", []))
    return t, st.get("updated", "")

def freq_info(coin):
    if coin not in COIN or not COIN[coin][3]:
        raise Bad("questa moneta non ha frequenze regolabili")
    if not installed(coin):
        raise Bad("%s non e' installata sulla BBB" % coin)
    p = prof_get(coin); tp, upd = temps(coin)
    a, _ = svc_state(coin)
    c = conf_read(coin)
    return {"coin": coin, "name": COIN[coin][1], "built": built_mhz(coin), "active": p["active"], "day": clean(p["day"]),
            "night": clean(p["night"]), "temps": tp, "updated": upd, "running": a in ("active", "activating"),
            "live": a == "active" and hup_ok(coin), "conf_freq": bool(c.get("freq") or c.get("freq_fpga")),
            "runsh": "--freq-file" in rd("%s/%s/%s_run.sh" % (CONFIG, coin, coin))}

def table(v, what):
    if not isinstance(v, list) or len(v) != NB:
        raise Bad("%s: tabella non valida" % what)
    out = []
    for b, row in enumerate(v):
        if not isinstance(row, list) or len(row) != NF:
            raise Bad("%s: board %d non valida" % (what, b))
        r = []
        for k, x in enumerate(row):
            n = num(x, 50, 450, "%s board %d chip %d (MHz)" % (what, b, k + 1))
            if n == "":
                raise Bad("%s board %d chip %d: manca il valore" % (what, b, k + 1))
            r.append(float(n))
        out.append(r)
    return out

def freq_set(coin, d):
    info = freq_info(coin)
    act = d.get("active", "day")
    if act not in ("day", "night"):
        raise Bad("profilo sconosciuto")
    p = {"active": act, "day": table(d.get("day"), "Giorno"), "night": table(d.get("night"), "Notte")}
    with LOCK:
        wr(prof_path(coin), json.dumps(p, indent=1) + "\n")
        if not d.get("apply"):
            return "profili salvati"
        wr(freq_path(coin), freq_json(p[act]))
        name = "Giorno" if act == "day" else "Notte"
        if not info["runsh"]:
            return "profilo %s salvato, ma %s_run.sh non passa --freq-file al miner: reinstalla il pacchetto bbb-update" % (name, coin)
        restart = False
        if info["conf_freq"]:                 # --freq / --freq-fpga in <moneta>.conf vincerebbero sul file: tolte
            c = conf_read(coin); c["pools"] = c["pools"]; f = dict(c); f["board_freq"] = []; f["freq"] = ""
            conf_save(coin, f); restart = True
        a, _ = svc_state(coin)
        if a not in ("active", "activating"):
            return "profilo %s salvato: vale al prossimo avvio di %s" % (name, coin.upper())
        if restart or not hup_ok(coin):
            run(["systemctl", "--no-block", "restart", coin + ".service"], 15)
            return "profilo %s applicato: miner riavviato (ricarica del bitstream ~40 s); dai prossimi cambi niente riavvio" % name
        run(["systemctl", "kill", "--kill-who=main", "-s", "SIGHUP", coin + ".service"], 10)
        return "profilo %s applicato al volo (il miner ha riletto le frequenze, nessun riavvio)" % name

# ---------------------------------------------------------------- azioni
LOCK = threading.Lock()

def others(coin):
    return [c[0] + ".service" for c in COINS if c[0] != coin]

def action(a, coin):
    if coin and coin not in COIN:
        raise Bad("moneta sconosciuta")
    with LOCK:
        if a in ("start", "restart"):
            if not installed(coin):
                raise Bad("%s non e' installata sulla BBB (manca /config/%s)" % (coin, coin))
            run(["systemctl", "stop"] + others(coin), 60)
            run(["systemctl", "--no-block", "restart" if a == "restart" else "start", coin + ".service"], 15)
            return "%s in avvio: caricamento del bitstream (~35-45 s), poi il miner" % COIN[coin][1]
        if a == "stop":
            run(["systemctl", "stop", coin + ".service"], 60); return "%s fermato" % COIN[coin][1]
        if a == "enable":
            run(["systemctl", "disable"] + others(coin), 30); run(["systemctl", "enable", coin + ".service"], 30)
            return "%s parte da solo all'accensione (gli altri no)" % COIN[coin][1]
        if a == "disable":
            run(["systemctl", "disable", coin + ".service"], 30); return "avvio automatico di %s tolto" % COIN[coin][1]
        if a == "reboot":
            threading.Timer(2, lambda: run(["systemctl", "reboot"], 30)).start(); return "la BBB si riavvia"
    raise Bad("azione sconosciuta")

# ---------------------------------------------------------------- sistema
def system():
    s = {"host": socket.gethostname(), "kernel": os.uname().release, "version": VERSION}
    try:
        s["uptime"] = int(float(rd("/proc/uptime").split()[0]))
        s["load"] = rd("/proc/loadavg").split()[:3]
        mi = dict((l.split(":")[0], int(l.split()[1])) for l in rd("/proc/meminfo").splitlines() if len(l.split()) >= 2)
        s["mem"] = [mi.get("MemTotal", 0) // 1024, mi.get("MemAvailable", mi.get("MemFree", 0)) // 1024]
        st = os.statvfs(CONFIG if os.path.isdir(CONFIG) else "/")
        s["disk_free_mb"] = st.f_bavail * st.f_frsize // 2 ** 20
    except Exception:
        pass
    _, ip = run(["hostname", "-I"], 5)
    s["ip"] = ip.split()
    return s

def status():
    coins, active = [], None
    for c in COINS:
        a, e = svc_state(c[0]) if installed(c[0]) else ("-", "-")
        coins.append({"id": c[0], "name": c[1], "algo": c[2], "mhz": built_mhz(c[0]), "note": c[4], "installed": installed(c[0]),
                      "active": a, "enabled": e})
        if a in ("active", "activating", "reloading") and active is None:
            active = c[0]
    last = active
    if not last:
        for c in coins:
            if c["enabled"] == "enabled":
                last = c["id"]; break
    st = parse(journal(last)) if last else None
    return {"coins": coins, "active": active, "shown": last, "since": svc_since(active) if active else None,
            "stats": st, "system": system(), "default_pw": webconf().get("default_pw", False), "time": time.strftime("%H:%M:%S")}

# ---------------------------------------------------------------- HTTP
class H(BaseHTTPRequestHandler):
    server_version = "bm-web/" + VERSION

    def log_message(self, fmt, *a):
        pass

    def auth(self):
        c = webconf()
        h = self.headers.get("Authorization", "")
        if h.startswith("Basic "):
            try:
                u, p = base64.b64decode(h[6:]).decode().split(":", 1)
                if u == c["user"] and hpw(c["salt"], p) == c["hash"]:
                    return True
            except Exception:
                pass
        time.sleep(0.5)
        self.send_response(401)
        self.send_header("WWW-Authenticate", 'Basic realm="BlackMiner BBB"')
        self.send_header("Content-Length", "0")
        self.end_headers()
        return False

    def out(self, code, body, ctype="application/json"):
        b = body if isinstance(body, bytes) else (json.dumps(body) if ctype == "application/json" else body).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype + "; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def body(self):
        n = int(self.headers.get("Content-Length", "0") or 0)
        if n > 65536:
            raise Bad("richiesta troppo grande")
        return json.loads(self.rfile.read(n).decode() or "{}")

    def q(self):
        from urllib.parse import urlparse, parse_qs
        u = urlparse(self.path)
        return u.path, {k: v[0] for k, v in parse_qs(u.query).items()}

    def do_GET(self):
        if not self.auth():
            return
        path, q = self.q()
        try:
            if path in ("/", "/index.html"):
                return self.out(200, PAGE, "text/html")
            if path == "/api/status":
                return self.out(200, status())
            if path == "/api/config":
                c = q.get("coin", "")
                if c not in COIN:
                    raise Bad("moneta sconosciuta")
                return self.out(200, {"coin": c, "conf": conf_read(c), "installed": installed(c)})
            if path == "/api/freq":
                return self.out(200, freq_info(q.get("coin", "")))
            if path == "/api/log":
                c = q.get("coin", "")
                if c not in COIN:
                    raise Bad("moneta sconosciuta")
                n = max(20, min(2000, int(q.get("n", "300"))))
                return self.out(200, {"lines": journal(c, n)})
            self.out(404, {"error": "non trovato"})
        except Bad as e:
            self.out(400, {"error": str(e)})
        except Exception as e:
            self.out(500, {"error": "errore interno: %s" % e})

    def do_POST(self):
        if not self.auth():
            return
        path, _ = self.q()
        if self.headers.get("X-BM", "") != "1":          # contro richieste da altri siti (CSRF)
            return self.out(403, {"error": "richiesta non valida"})
        try:
            d = self.body()
            if path == "/api/config":
                c = d.get("coin", "")
                if c not in COIN:
                    raise Bad("moneta sconosciuta")
                if not installed(c):
                    raise Bad("%s non e' installata sulla BBB" % c)
                line = conf_save(c, d.get("conf", {}))
                msg = "salvato in /config/%s/%s.conf" % (c, c)
                if d.get("start"):
                    msg += "; " + action("restart", c)
                elif svc_state(c)[0] in ("active", "activating"):
                    msg += " (il miner acceso usa ancora le impostazioni vecchie: 'Salva e avvia' per applicarle)"
                if d.get("autostart") is True:
                    msg += "; " + action("enable", c)
                elif d.get("autostart") is False:
                    action("disable", c)
                return self.out(200, {"ok": True, "message": msg, "line": line})
            if path == "/api/freq":
                return self.out(200, {"ok": True, "message": freq_set(d.get("coin", ""), d)})
            if path == "/api/action":
                return self.out(200, {"ok": True, "message": action(d.get("action", ""), d.get("coin", ""))})
            if path == "/api/password":
                pw = str(d.get("password", ""))
                if len(pw) < 6:
                    raise Bad("almeno 6 caratteri")
                c = webconf(); c["hash"] = hpw(c["salt"], pw); c["default_pw"] = False
                if d.get("user"):
                    c["user"] = safe(d["user"], "utente")
                wr(WEBCONF, json.dumps(c, indent=1)); os.chmod(WEBCONF, 0o600)
                return self.out(200, {"ok": True, "message": "password cambiata: il browser la richiedera'"})
            self.out(404, {"error": "non trovato"})
        except Bad as e:
            self.out(400, {"error": str(e)})
        except Exception as e:
            self.out(500, {"error": "errore interno: %s" % e})

class Srv(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

PAGE = "@PAGE@"

def main():
    global PAGE
    here = os.path.dirname(os.path.abspath(__file__))
    PAGE = rd(os.path.join(here, "bm-web.html")) or "<h1>manca bm-web.html</h1>"
    webconf()
    ports = [int(a) for a in sys.argv[1:] if a.isdigit()] or [int(webconf().get("port", 80)), 8080, 8888, 8000, 8181]
    for port in ports:
        try:
            s = Srv(("", port), H)
        except OSError as e:
            print("porta %d non disponibile (%s)" % (port, e), flush=True)
            continue
        print("bm-web %s in ascolto sulla porta %d" % (VERSION, port), flush=True)
        s.serve_forever()
    sys.exit(1)

if __name__ == "__main__":
    main()
