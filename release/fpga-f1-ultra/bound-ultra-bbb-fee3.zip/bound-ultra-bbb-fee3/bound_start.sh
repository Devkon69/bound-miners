#!/bin/sh
# bound_start.sh - BOUND sulla BeagleBone Black rev C con carrier BlackMiner (F1 Ultra), ventole a 4 fili
#
#   sudo sh /config/bound/bound_start.sh bench [secondi]   pin, bitstream e prova senza pool (default 60 s)
#   sudo sh /config/bound/bound_start.sh start             mining in background (servizio bound, ferma gli altri miner)
#   sudo sh /config/bound/bound_start.sh stop
#   sudo sh /config/bound/bound_start.sh log               log in diretta (Ctrl-C per uscire)
#   sudo sh /config/bound/bound_start.sh enable|disable    avvio automatico all'accensione
#   sudo sh /config/bound/bound_start.sh status
#   sudo sh /config/bound/bound_start.sh pins              imposta i pin con config-pin (solo a runtime)
#   sudo sh /config/bound/bound_start.sh fan-info          stato di PWM e tachimetri
#   sudo sh /config/bound/bound_start.sh fan PCT           ventole a PCT % e misura dei giri (miner fermo)
#
# Ventole (es. Noctua industrialPPC-3000 PWM): attive se esiste /config/bound/fan.conf (PWM a 25 kHz
# su P9_29, giri da P9_18 e P9_41); curva in bound.conf con --fan-min 20 --fan-max 100.
# Senza fan.conf, o con --no-fan in bound.conf, le ventole non vengono comandate.
#
# Opzioni del miner in /config/bound/bound.conf (una riga), per esempio:
#   --pool stratum+tcp://IP_DEL_PC:7340 --user TUO_INDIRIZZO.ultra1 --freq-max 90 --fan-min 20 --fan-max 100
# Non modifica nulla dell'avvio (uEnv.txt, overlay, dtb): usa cape-universal + config-pin.
DIR=/config/bound
export BM_FAN_CONF=$DIR/fan.conf
BIT=/fpgabit/fpgaminer_top_bound.bit
OTHERS="prox rigor ting noid mds verus aln csd qtc quip nock"
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
[ "$(id -u)" = 0 ] || { echo "lancia con sudo"; exit 1; }

# stessi pin del bench riuscito il 13/10 (cape-universal attivo)
pins() {
    command -v config-pin >/dev/null || { echo "config-pin non trovato: salto i pin"; return 0; }
    for p in P9_24 P9_26 P9_21 P9_22 P9_11 P9_13 P8_37 P8_38; do config-pin $p uart >/dev/null 2>&1 || echo "config-pin $p uart: errore"; done
    for p in P9_28 P8_27 P9_42 P9_31 P9_30 P9_25 P8_12 P8_16 P8_28; do config-pin $p gpio >/dev/null 2>&1 || echo "config-pin $p gpio: errore"; done
    for p in P8_19 P8_17 P8_15 P9_27; do config-pin $p gpio_pd >/dev/null 2>&1 || echo "config-pin $p gpio_pd: errore"; done
    return 0
}

# opzioni di bound.conf utili al bench (ventole, frequenza, soglie termiche, porte)
bench_opts() {
    [ -f $DIR/bound.conf ] || return 0
    awk '{ for (i = 1; i <= NF; i++) {
             if ($i == "--no-fan" || $i == "--overclock") printf "%s ", $i
             else if ($i ~ /^--(fan|fan-min|fan-max|fan-irq|pwm-path|pwm-period|freq|freq-fpga|freq-max|vco-max|trip|resume|port|max-cands)$/) { printf "%s %s ", $i, $(i+1); i++ }
         } }' $DIR/bound.conf
}

# opzioni ventola preparate da bm-fan.sh (vuoto = ventole non gestite)
fan_args() {
    [ -f $DIR/fan.conf ] || return 0
    bm-fan.sh setup >&2 && [ -s /run/blackminer-fan.args ] && cat /run/blackminer-fan.args
}

case "$1" in
    pins) pins; echo "pin impostati" ;;
    bench)
        systemctl stop bound $OTHERS 2>/dev/null
        pins
        bmctl init >/dev/null 2>&1
        bmctl load $BIT || { echo "caricamento bitstream fallito"; exit 1; }
        OPTS=$(bench_opts)
        ARGS=""
        case "$OPTS" in
            *--port*) ;;
            *) PORTS=$(bmctl detect) || { echo "nessuna board rilevata"; bmctl detect -v; exit 1; }
               for p in $PORTS; do ARGS="$ARGS --port $p"; done ;;
        esac
        case "$OPTS" in
            *--no-fan*) FAN="" ;;
            *) FAN=$(fan_args); [ -n "$FAN" ] || OPTS="$OPTS --no-fan" ;;
        esac
        echo "porte:$ARGS   opzioni: $FAN $OPTS"
        $DIR/bound-miner $ARGS $FAN $OPTS --bench ${2:-60}
        ;;
    start)
        [ -s $DIR/bound.conf ] || { echo "crea prima $DIR/bound.conf"; exit 1; }
        grep -q -e TUO_INDIRIZZO -e IP_DEL_PC $DIR/bound.conf && { echo "in $DIR/bound.conf metti l'IP del PC col ponte al posto di IP_DEL_PC e il tuo indirizzo BOUND (B...) al posto di TUO_INDIRIZZO"; exit 1; }
        systemctl stop $OTHERS 2>/dev/null
        systemctl start bound && echo "mining avviato: sudo sh $0 log"
        ;;
    stop)    systemctl stop bound; echo "fermato (gli FPGA si fermano da soli entro il watchdog)" ;;
    log)     journalctl -u bound -f -n 100 ;;
    enable)  systemctl disable $OTHERS 2>/dev/null; systemctl enable bound ;;
    disable) systemctl disable bound ;;
    status)  systemctl status bound --no-pager; bmctl detect -v ;;
    fan-info) bm-fan.sh info ;;
    fan)     bm-fan.sh set "$2" ;;
    *) sed -n '2,20p' "$0" ;;
esac
