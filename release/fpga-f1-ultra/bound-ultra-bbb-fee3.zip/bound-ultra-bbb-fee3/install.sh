#!/bin/sh
# install.sh - copia i file BOUND (F1 Ultra, bitstream 7 core BoundHash, build a 90 MHz, ventole a 4 fili) sulla BeagleBone Black rev C
# e installa bm-web 1.6 (frequenze per chip al volo, profili Giorno / Notte).
# NON tocca uEnv.txt, overlay, dtb o bootloader. Gli altri miner (Proxima, RIGOR, TING, NOID, MDS, Verus, ALN, ...) restano
# installati: il servizio bound li ferma quando parte. I file sostituiti vengono salvati con suffisso .prima
set -e
[ "$(id -u)" = 0 ] || { echo "lancia con sudo"; exit 1; }
cd "$(dirname "$0")"
[ -f fpgaminer_top_bound.bit ] || { echo "manca fpgaminer_top_bound.bit nel pacchetto"; exit 1; }
md5sum -c md5sums.txt >/dev/null || { echo "pacchetto rovinato (md5sums.txt non torna): riscaricalo"; exit 1; }
mkdir -p /config/bound /fpgabit
bk() { [ -f "$1" ] && [ ! -f "$1.prima" ] && cp -p "$1" "$1.prima"; return 0; }
for f in bound-miner bound_start.sh bound_run.sh; do bk /config/bound/$f; done
bk /fpgabit/fpgaminer_top_bound.bit; bk /etc/systemd/system/bound.service; bk /usr/local/sbin/bm-fan.sh
systemctl stop bound 2>/dev/null || true
install -m 755 bound-miner bound_start.sh bound_run.sh /config/bound/
install -m 644 fpgaminer_top_bound.bit /fpgabit/
# bm-fan.sh 0.4 (stesso degli altri pacchetti BBB)
install -m 755 bm-fan.sh /usr/local/sbin/bm-fan.sh
[ -f /config/bound/fan.conf ] || { install -m 644 fan.conf /config/bound/fan.conf; echo "creato /config/bound/fan.conf (ventole attive)"; }
cp bound.conf.esempio /config/bound/bound.conf.esempio
cp LEGGIMI.txt /config/bound/LEGGIMI.txt
if [ -f /config/bound/bound.conf ]; then
    grep -q -- "--no-fan" /config/bound/bound.conf && echo "ATTENZIONE: bound.conf contiene --no-fan: toglilo per comandare le ventole"
    grep -q -e TUO_INDIRIZZO -e IP_DEL_PC /config/bound/bound.conf && echo "ATTENZIONE: in bound.conf metti il tuo indirizzo BOUND (B...) al posto di TUO_INDIRIZZO (e, se mini in solitaria, l'IP del PC col ponte al posto di IP_DEL_PC)"
    grep -q -- "--freq-max" /config/bound/bound.conf || echo "ATTENZIONE: aggiungi --freq-max 90 a bound.conf (il bitstream non regge di piu')"
    true
else
    cp bound.conf.esempio /config/bound/bound.conf
    echo "creato /config/bound/bound.conf: metti il tuo indirizzo BOUND (B...) al posto di TUO_INDIRIZZO (e, se mini in solitaria, l'IP del PC col ponte al posto di IP_DEL_PC) (sudo nano /config/bound/bound.conf)"
fi
if [ -x /usr/local/sbin/bmctl ]; then
    echo "bmctl presente: $(/usr/local/sbin/bmctl 2>&1 | head -n 1)"
else
    install -m 755 bin/bmctl /usr/local/sbin/bmctl
    echo "bmctl 0.2.2 installato"
fi
[ -f /etc/blackminer/pins.conf ] || echo "ATTENZIONE: /etc/blackminer/pins.conf mancante"
grep -q '^LOAD_MODE=gpio' /etc/blackminer/pins.conf 2>/dev/null || echo "ATTENZIONE: in /etc/blackminer/pins.conf serve LOAD_MODE=gpio"
install -m 644 bound.service /etc/systemd/system/bound.service
# frequenza iniziale: 90 MHz (il bitstream e' costruito per 90);
# poi la scheda Frequenza di bm-web scrive questo file
[ -f /config/bound/freq.json ] || { echo '{ "freq" : "90" }' > /config/bound/freq.json; echo "creato /config/bound/freq.json (90 MHz)"; }
grep -q -- "--freq" /config/bound/bound.conf 2>/dev/null && echo "nota: bound.conf contiene --freq/--freq-fpga: vincono sulla scheda Frequenza di bm-web finche' ci sono (al primo SALVA E APPLICA bm-web le toglie)"
# bm-web 1.6 (interfaccia web della BBB, scheda Frequenza: un riquadro per chip, temperatura, profili Giorno / Notte)
mkdir -p /config/bm-web
for f in bm-web.py bm-web.html; do [ -f /config/bm-web/$f ] && [ ! -f /config/bm-web/$f.prima ] && cp -p /config/bm-web/$f /config/bm-web/$f.prima; done
install -m 755 bm-web.py /config/bm-web/bm-web.py
install -m 644 bm-web.html /config/bm-web/bm-web.html
[ -f /etc/systemd/system/bm-web.service ] || install -m 644 bm-web.service /etc/systemd/system/bm-web.service
systemctl daemon-reload
systemctl enable bm-web >/dev/null 2>&1 || true
systemctl restart bm-web || true
echo "bm-web 1.6: http://$(hostname -I | awk '{print $1}')/  (utente root / password root se non l'hai cambiata) > scheda Frequenza"
echo "fatto. Prova:  sudo sh /config/bound/bound_start.sh bench 60"
